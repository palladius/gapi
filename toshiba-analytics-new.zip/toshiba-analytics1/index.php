<?php require 'config/base.php'; ?>
<link type="text/css" href="style/ui-lightness/jquery-ui-1.8.16.custom.css" rel="stylesheet" />
<link type="text/css" href="style/style.css" rel="stylesheet" />
<script type="text/javascript" src="https://www.google.com/jsapi"></script>
<script type="text/javascript" src="js/jquery-1.6.3.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.8.16.custom.min.js"></script>
<script type="text/javascript">
    $(function(){
        $("#from_date").datepicker({ dateFormat : 'M dd, yy', maxDate: '0m' });
        $("#to_date").datepicker({ dateFormat : 'M dd, yy', maxDate: '0m'});
    });

    function drawLineChart(val, container_id)
    {
        var data = google.visualization.arrayToDataTable(val);
        var chart = new google.visualization.LineChart(document.getElementById(container_id));
        chart.draw(data,
        {
            backgroundColor: { },
            borderColor: 'none',
            enableInteractivity: false,
            legend: 'none',
            width: 100,
            height: 30,
            title: '',
            hAxis: { textPosition: 'none',gridlineColor: 'none' },
            vAxis: { textPosition: 'none', gridlineColor: 'none', baselineColor: '#FFF'}
        });

    }

    function drawPieChart(val, container_id)
    {
        var data = google.visualization.arrayToDataTable(val);
        var chart = new google.visualization.PieChart(document.getElementById(container_id));
        chart.draw(data,
        {
            backgroundColor: { },
            borderColor: 'none',
            enableInteractivity: true,
            legend: 'right',
            width: 320,
            height: 230,
            title: '',
            hAxis: { textPosition: 'none',gridlineColor: 'none' },
            vAxis: { textPosition: 'none', gridlineColor: 'none'}
        });
    }


</script>


<?php

if(isset($_REQUEST['profile_id']))
{
    if($_REQUEST['from_date'] != "" && $_REQUEST['to_date'] != "")
    {               
        $start_date = date('Y-m-d',  strtotime($_REQUEST['from_date']));
        $end_date = date('Y-m-d',  strtotime($_REQUEST['to_date']));
    }
    
    $profile_id = $_REQUEST['profile_id'];
    // Dimension:Visits, Pageviews / Metrics:Date
    $dimension = array('date');
    $metrics = array('visits','pageviews');
    $sort_metric = 'date';

    $result_data = getAnalyticsReportData($ga, $profile_id, $dimension, $metrics, $sort_metric, null, $start_date, $end_date, $start_index, $max_results);

if($result_data)
{

    // Visits-Date
    $total_visits = 0;
    $chart_data1 = "[['date','visits'],";
    foreach($result_data as $data)
    {
        $chart_data1 .= "['".$data->getDate()."',".$data->getVisits()."],";
        $total_visits += $data->getVisits();
    }
    $chart_data1 = rtrim($chart_data1,",");
    $chart_data1 .= "]";    
    $total_visits = number_format($total_visits)." Visits";

    
    // Page Views-Date
    $total_pageviews = 0;
    $chart_data2 = "[['date','pageviews'],";
    foreach($result_data as $data)
    {
        $chart_data2 .= "['".$data->getDate()."',".$data->getPageviews()."],";
        $total_pageviews += $data->getPageviews();
    }
    $chart_data2 = rtrim($chart_data2,",");
    $chart_data2 .= "]";
    $total_pageviews = number_format($total_pageviews)." Pageviews";


    // Pages/Visits
    if( 0 != $total_visits ){
        $total_page_visits = $total_pageviews / $total_visits;
    }
    else{
        $total_page_visits = 0;
    }
    $total_page_visits = round($total_page_visits,2)." Pages/Visits";

    $chart_data3 = "[['date','page_visits'],";
    foreach($result_data as $data)
    {
        if( 0 != $data->getVisits()){
        $page_visits = round($data->getPageviews() / $data->getVisits(),2);
        }
        else{
            $page_visits = 0;
        }
        $chart_data3 .= "['".$data->getDate()."',".$page_visits."],";
    }
    $chart_data3 .= "]";
}

        // Dimension:Medium / Metrics:Visits
        $dimension = array('medium');
        $metrics = array('visits');
        $sort_metric = 'visits';

        $result_data = getAnalyticsReportData($ga, $profile_id, $dimension, $metrics, $sort_metric, null, $start_date, $end_date, $start_index, $max_results);

        if($result_data)
        {
            $chart_data4 = "[['medium','visits'],";
            foreach($result_data as $data)
            {
                if($data->getMedium() == 'organic'){ $medium = 'Search Engines'; }
                if($data->getMedium() == 'referral'){ $medium = 'Referring Sites'; }
                if($data->getMedium() == '(none)'){ $medium = 'Direct Traffic'; }
                $chart_data4 .= "['".$medium."',".$data->getVisits()."],";
            }
            $chart_data4 = rtrim($chart_data4,",");
            $chart_data4 .= "]";
        }

}
?>

<?php if($chart_data1 != ""): ?>
<script type="text/javascript">
    
    var val1 = <?php echo $chart_data1 ?>;    
    google.load("visualization", "1", {packages:["corechart"]});
    google.setOnLoadCallback(drawChart);
    function drawChart() { drawLineChart(val1, "visits_img");  }

</script>
<?php endif; ?>

<?php if($chart_data2 != ""): ?>
<script type="text/javascript">

    var val2 = <?php echo $chart_data2 ?>;
    google.load("visualization", "1", {packages:["corechart"]});
    google.setOnLoadCallback(drawChart);
    function drawChart() { drawLineChart(val2, "page_views_img");  }
    
</script>
<?php endif; ?>

<?php if($chart_data3 != ""): ?>
<script type="text/javascript">
    
    var val3 = <?php echo $chart_data3 ?>;
    google.load("visualization", "1", {packages:["corechart"]});
    google.setOnLoadCallback(drawChart);
    function drawChart() { drawLineChart(val3, "page_visits_img");  }
    
</script>
<?php endif; ?>

<?php if($chart_data4 != ""): ?>
<script type="text/javascript">

    var val4 = <?php echo $chart_data4 ?>;
    google.load("visualization", "1", {packages:["corechart"]});
    google.setOnLoadCallback(drawChart);
    function drawChart() { drawPieChart(val4, "traffic_source");  }

</script>
<?php endif; ?>

<div id="analytic_panel_form" >
    <h2>Google Analytic Report</h2>
    <form action="<?php $_SERVER['PHP_SELF'] ?>" method="post">
        <table cellpadding="4">
            <tr>
                <td><label for="profile_id">Select Profile :</label></td>
                <td>
                    <select id="profile_id" name="profile_id" >
                    <option selected disabled>Select Profile From List</option>
                    <?php foreach($profile as $title => $id): ?>
                        <option value="<?php echo $id ?>"><?php echo $id.' - '.$title ?></option>
                    <?php endforeach; ?>
                    </select>
                </td>
            <tr>
                <td><label for="from_date">Date From :</label></td>
                <td><input type="text" id="from_date" name="from_date" /></td>
            </tr>
            <tr>
                <td><label for="to_date">Date To :</label></td>
                <td><input type="text" id="to_date" name="to_date" /></td>
            </tr>
            <tr>
                <td></td>
                <td><input type="submit" value="Submit" /><input type="reset" /></td>
            </tr>        
        </table>
    </form>
</div>

<div id="main_container">
<div id="analytic_panel">    
<?php if(isset($_REQUEST['profile_id'])): ?>    
        <div class="inner_container profile">
                <?php foreach($profile as $title => $id): ?>
                <?php if($_REQUEST['profile_id'] == $id){ echo '<b>'.$title.'-'.$id.'</b>'; } ?>
                <?php endforeach; ?>
        </div>
    <div class="left_container">
        <div class="inner_container date_range">
                <?php echo date('M j, Y',strtotime($start_date)).' - '.date('M j, Y',strtotime($end_date)) ?>
        </div>
        <div class="inner_container visits">
            <div id="visits_img" class="graph_img"></div>
            <div class="graph_txt"><?php echo $total_visits ?></div>
            <div class="clearfix"></div>
        </div>
        <div class="inner_container pageviews">
            <div id="page_views_img" class="graph_img"></div>
            <div class="graph_txt"><?php echo $total_pageviews ?></div>
            <div class="clearfix"></div>
        </div>
        <div class="inner_container pagevisits">
            <div id="page_visits_img" class="graph_img"></div>
            <div class="graph_txt"><?php echo $total_page_visits ?></div>
            <div class="clearfix"></div>
        </div>
    </div>
    
    <div class="inner_container trafficsource">
        <div id="traffic_source"></div>
    </div>
    
<?php endif; ?>
    <div class="clearfix"></div>
    <div class="footer_panel"></div>
</div>    
</div>

