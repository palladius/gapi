<?php

require 'lib/gapi-1.3/gapi.class.php';
require 'config/account.php';

$profile_id = array();
$current_date = date('Y-m-d');
$prev_month_date = strtotime('-30 day', strtotime($current_date));
$prev_month_date = date('Y-m-d', $prev_month_date);
$start_date = $prev_month_date;
$end_date = $current_date;
$start_index = 1;
$max_results = 10000;


try{
    $ga = new gapi($account_user['username'], $account_user['password']);

    $profile = getAccountProfile($ga, $account_user);
    
}catch(Exception $e){
    echo $e->getMessage();
    exit();
}


// Retrive ProfileId from Account
function getAccountProfile($ga, $account_user)
{
    $gaAccountData = $ga->requestAccountData();
    
    foreach($ga->getResults() as $accountDetail)
    {        
        $profile[$accountDetail->getTitle()] =  $accountDetail->getProfileId();
    }    
    return $profile; // Return array
}

// Retrive Analytics Report Data
function getAnalyticsReportData($ga, $profile_id, $dimensions, $metrics, $sort_metric, $filter, $start_date, $end_date, $start_index, $max_results)
{    
    // Set First profile Id    
    if(!empty($profile_id)){
        $ga->requestReportData($profile_id, $dimensions, $metrics, $sort_metric, $filter, $start_date, $end_date, $start_index, $max_results);
        return $ga->getResults();
    }
    else{
        return false;
    }
}
?>